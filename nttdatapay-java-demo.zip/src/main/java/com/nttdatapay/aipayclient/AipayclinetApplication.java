package com.nttdatapay.aipayclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author SurajChavan
 *
 */
@SpringBootApplication
public class AipayclinetApplication {

	public static void main(String[] args) {
		SpringApplication.run(AipayclinetApplication.class, args);
	}

}
