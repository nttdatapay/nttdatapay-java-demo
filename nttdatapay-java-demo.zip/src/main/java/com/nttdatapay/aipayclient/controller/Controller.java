package com.nttdatapay.aipayclient.controller;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.nttdatapay.aipayclient.model.ResponseParser;
//import com.nttdatapay.IntentUPI.entity.ProdDetails;
import com.nttdatapay.aipayclient.pojo.CustDetails;
import com.nttdatapay.aipayclient.pojo.Extras;
import com.nttdatapay.aipayclient.pojo.MerchDetails;
import com.nttdatapay.aipayclient.pojo.PayDetails;
import com.nttdatapay.aipayclient.pojo.PayInstrument;
import com.nttdatapay.aipayclient.pojo.ProdDetail;
import com.nttdatapay.aipayclient.pojo.HeadDetails;
import com.nttdatapay.aipayclient.pojo.OtsTransaction;
import com.nttdatapay.aipayclient.pojo.ServerResponse;
import com.nttdatapay.aipayclient.utils.AuthEncryption;
//import com.sun.tools.javac.util.List;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;

/**
 * @author SurajChavan
 *
 */
@org.springframework.stereotype.Controller
public class Controller {

	@RequestMapping("/payNow")
	public String payNow(String atomMid, String amount, String merchTxnId, String returnURL,String RegistrationFee,String BidSecurity,String FinalPayment,String Udf1,String Udf5,String udf4, Model model) {

		String encryptedData = "";
		String decryptedData = "";

		System.out.println("############################ PayController Post #########################");

		String merchantId = atomMid;

		String merchantTxnId = merchTxnId;

		System.out.println("MerchantId------: " + merchantId);
		System.out.println("Amount----------: " + amount);
		System.out.println("MerchantTxnId---: " + merchantTxnId);
		System.out.println("ReturnURL-------: " + returnURL);
		System.out.println("RegistrationFee :"+RegistrationFee);
		System.out.println("BidSecurity :"+BidSecurity);
		System.out.println("FinalPayment :"+FinalPayment);
		System.out.println("Udf1 :"+Udf1);
		System.out.println("Udf5 :"+Udf5);
		System.out.println("Udf4 :"+udf4);
		
		MerchDetails merchDetails = new MerchDetails();
		merchDetails.setMerchId(merchantId);
		merchDetails.setMerchTxnId(merchantTxnId);
		merchDetails.setUserId("");
		merchDetails.setPassword("Test@123");
		DateTimeFormatter myFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime date = LocalDateTime.now();
		String dateFormat = myFormat.format(date);
		merchDetails.setMerchTxnDate(dateFormat);

		PayDetails payDetails = new PayDetails();
		payDetails.setProduct("Multi");
		payDetails.setAmount(amount);
		payDetails.setCustAccNo("213232323");
		payDetails.setTxnCurrency("INR");
		
		
		ProdDetail prodDetail = new ProdDetail();
		List<ProdDetail> prodList = new ArrayList<>();
		
		System.out.println("RegistrationFee"+RegistrationFee);
		prodDetail.setProdName("RegistrationFee");
		BigDecimal bd =new BigDecimal(RegistrationFee);
		prodDetail.setProdAmount(bd);
		prodList.add(prodDetail);
		
		System.out.println("BidSecurity"+BidSecurity);
		ProdDetail prodDetail1 = new ProdDetail();
		prodDetail1.setProdName("BidSecurity");
		BigDecimal bd1 =new BigDecimal(BidSecurity);
		prodDetail1.setProdAmount(bd1);
		prodList.add(prodDetail1);
		
		if(!ObjectUtils.isEmpty(FinalPayment)) {
		System.out.println("FinalPayment"+FinalPayment);
		ProdDetail prodDetail2 = new ProdDetail();
		BigDecimal bd2 =new BigDecimal(FinalPayment);
		prodDetail2.setProdName("finalpayment");
		prodDetail2.setProdAmount(bd2);
		prodList.add(prodDetail2);
		}
		payDetails.setProdDetails(prodList);
	
		CustDetails custDetails = new CustDetails();
//		custDetails.setCustEmail("");
//		custDetails.setCustMobile("");
		custDetails.setCustFirstName("Suraj");
		HeadDetails headDetails = new HeadDetails();
		headDetails.setApi("AUTH");
		headDetails.setVersion("OTSv1.1");
		headDetails.setPlatform("FLASH");

		Extras extras = new Extras();
		extras.setUdf1(Udf1);
		extras.setUdf2("");
		extras.setUdf3("");
		extras.setUdf4(udf4);
		extras.setUdf5(Udf5);
//		extras.setUdf9("345");
		PayInstrument payInstrument = new PayInstrument();

		payInstrument.setMerchDetails(merchDetails);
		payInstrument.setPayDetails(payDetails);
		payInstrument.setCustDetails(custDetails);
		payInstrument.setHeadDetails(headDetails);
		payInstrument.setExtras(extras);

		OtsTransaction otsTxn = new OtsTransaction();
		otsTxn.setPayInstrument(payInstrument);

		Gson gson = new Gson();
		String json = gson.toJson(otsTxn);
		System.out.println("Final JsonOutput----: " + json);

		String serverResp = "";
		String decryptResponse = "";
		try {
			AuthEncryption authEncryption = new AuthEncryption();
//			encryptedData = AuthEncryption.getAuthEncrypted(json, "14F8886E0BFD3888CFCD6B7944444A7D");
			encryptedData = AuthEncryption.getAuthEncrypted(json, "A4476C2062FFA58980DC8F79EB6A799E");
			
			System.out.println("EncryptedData------: " + encryptedData);

			serverResp = AipayService.getAtomTokenId(merchantId, encryptedData);
			System.out.println("serverResp Result------: " + serverResp);
			System.out.println("serverResp Length------: " + serverResp.length());
			System.out.println("serverResp Condition---: " + serverResp.startsWith("merchId"));

			if ((serverResp != null) && (serverResp.startsWith("merchId"))) {
				decryptResponse = serverResp.split("\\&encData=")[1];
				System.out.println("serrResp---: " + decryptResponse);

//				decryptedData = AuthEncryption.getAuthDecrypted(decryptResponse, "F9F950C5BC56801EFCD003A6259EABDC");
				decryptedData = AuthEncryption.getAuthDecrypted(decryptResponse, "75AEF0FA1B94B3C10D4F5B268F757F11");
				System.out.println("DecryptedData------: " + decryptedData);

				ServerResponse serverResponse = new ServerResponse();
				serverResponse = (ServerResponse) gson.fromJson(decryptedData, ServerResponse.class);

				String atomTokenId = serverResponse.getAtomTokenId();
				System.out.println("serverResponse-----: " + serverResponse);
				System.out.println("TokenId------------: " + atomTokenId);
				model.addAttribute("TokenId", atomTokenId);
				model.addAttribute("amount", amount);
				model.addAttribute("merchantId", merchantId);
				model.addAttribute("returnURL", returnURL);
				model.addAttribute("suraj", "suraj");

			} else {
				String errorDescription = "Something Went Wrong!";
				System.out.println("Something Went Wrong!");
				model.addAttribute("errorDescription", errorDescription);
				return "error";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}

		return "checkout";
	}

	@RequestMapping("/response")
	public String responsee(String encData, Model model) throws JsonMappingException, JsonProcessingException {
		System.out.println("response received");
		System.out.println(encData);
		String decryptedData = AuthEncryption.getAuthDecrypted(encData, "75AEF0FA1B94B3C10D4F5B268F757F11");
		System.out.println(decryptedData);
		model.addAttribute("encData", encData);
		ObjectMapper objectMapper = new ObjectMapper();
		ResponseParser resp = objectMapper.readValue(decryptedData, ResponseParser.class);
		System.out.println(resp.getPayInstrument().getResponseDetails().getMessage());
		model.addAttribute("message", resp.getPayInstrument().getResponseDetails().getMessage());
		model.addAttribute("merchTxnId", resp.getPayInstrument().getMerchDetails().getMerchTxnId());
		model.addAttribute("merchTxnDate", resp.getPayInstrument().getMerchDetails().getMerchTxnDate());
		model.addAttribute("bankTxnId",
				resp.getPayInstrument().getPayModeSpecificData().getBankDetails().getBankTxnId());
		return "response received";
	}

	public static String getkeys() {
		return "";
	}

	@RequestMapping("/respwonse")
	public String response(String encData, Model model) throws JsonMappingException, JsonProcessingException {
		String responseKeyString = "F9F950C5BC56801EFCD003A6259EABDC";
		String decryptedData = AuthEncryption.getAuthDecrypted(encData, responseKeyString);
		model.addAttribute("encData", encData);
		ObjectMapper objectMapper = new ObjectMapper();
		ResponseParser response = objectMapper.readValue(decryptedData, ResponseParser.class);
		model.addAttribute("message", response.getPayInstrument().getResponseDetails().getMessage());
		model.addAttribute("merchTxnId", response.getPayInstrument().getMerchDetails().getMerchTxnId());
		model.addAttribute("merchTxnDate", response.getPayInstrument().getMerchDetails().getMerchTxnDate());
		model.addAttribute("bankTxnId",
				response.getPayInstrument().getPayModeSpecificData().getBankDetails().getBankTxnId());
		return response.toString();
	}
	public static void main(String[] args) {
		String respString="437ACE570FEB00DB0B64DFC5F5B41281FE33A3AACD87472B3904CAEFF6C146AAF3788BF06E8FDABBE8098D1416E8A7D8A69170218529E853DA56B6DE8AC79D9AE1770D141132E2320AED9BBA439E37A49B3BA7C5BEFB261FD071B9F3D0D6B19A6BEF60DC103BE58121287EF4D285946F7682545E5F1A628F02BBB42545D7C5A46D497BABDD90BC9A34CA507F630E5EBF2E9D39DC77AD350A0BA86AE7A0679C99B27D8F016EFE47465241FF3D1E0AC3C5F202D2D8C04E4819FD19CCF4970B5A08DCC71BCCAC11DCAEFEEEEC6C53831792F730148CE054F5583B3C2B3DDC320083B7EF840B4EDA4607FC91A30BF811B1026CA2831F9853FE478AE0B6221F9F057ADD0A88B659DC1412B5AEFABBCBDF68B4D777D7599B408E91FF55B3AF8409BB9F5947F6478540C053C3D0664FEE586F4586201EE6362A5CBD8645C47C0E7A90DCC8463DDFF67AB013406D4DF2F207170F56F5C3829E6C885FAA53AEAEC1D57CC58DBABFBE7114A5D7C2A06DC7C973101E9C7D4B8795430A10AA2524311B872DF3681FBEF3E14439C207930E833D1D64D50CAD4981FF223DCE8248A2B0134906B50A90D3963A88905574C6E1D565F38CFD4FDFDE2ED97C42B7DE7B19B2036D692ECAF6B92CB94E9AB0D8304896ADDD41A1FE1B2178942607B24ACDB237DEB1BC3C87869FEE10E3634D5B4F22AAB4F5DE871084D1D215E977309990F5987D076081B79095BD89D7F14BCECFE9F3D1E69E7F5EBBBD293742B1F8354AE53EA07A402679E90F1795632A0C3C5FEE836CDB831A689A74B67BC808B1720AB93FA3F436D262771971EF4B8769BC79D8672F555E84C4BBB466BF8446CF9AB39EBD57723C3A6A37D0143A8A9948B6D54FC12BB3AD631D5F16515835A0960504A051F2EDA826EEE7DCDD774CBB278DA33429F420CC7BF1E516174604318578780E853B7605925BA3DD853F3460736AD12476A1EB749C962BC7BC376D845D150EF6E4EDA506DB1E365A5DEEC5392110D3A33405E6B2AE6302F4E59D2FC0F3A755522F088B9E2DB648C274D87C10446CA12A4C23C8B2240E99141990334F45E3D7DC33AE5D6B8DFFB7232D93B7F16BA59A882E1B35F5DF63AFBCE2768A478959EF991BA24C4E846C578C44938E5B2A252641E8302B19E45E26E057AEF1026983B3209924BF82FBDEA2C536481AC75AB9B07FCD15B75F3DB6E05218EFCB8E85B59A01B6151ED4625773A643DC787532FD7F25E07AA0FFA8907506BCF87F5055BADA2D03C8D8DA3C97BED3317BD3B4D3E554E9D4D5B0AA9E2E10EDBD9BD3C93F1B3E6439551C79AEB24351AD1A3C2625D994E82B16203FBB05EF23AE799DC71BDC466F09139C237DCDA52BDD2DBFC0A5B8288ECDB8682813";
		String decResponseString=AuthEncryption.getAuthDecrypted(respString, "F9F950C5BC56801EFCD003A6259EABDC");
		System.out.println(decResponseString);
	}
}
