package com.nttdatapay.aipayclient.controller;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdatapay.aipayclient.model.ResponseParser;

public class Test {
	  public static void main(String[] args)
	  {
	    String resp = "{\"payInstrument\":{\"merchDetails\":{\"merchId\":8952,\"merchTxnId\":\"563265656566\",\"merchTxnDate\":\"2021-05-19T10:02:10\"},\"payDetails\":{\"atomTxnId\":11000000097378,\"prodDetails\":[{\"prodName\":\"NSE\",\"prodAmount\":10.0}],\"amount\":10.00,\"surchargeAmount\":0.00,\"totalAmount\":10.00,\"custAccNo\":\"213232323\",\"clientCode\":\"1234\",\"txnCurrency\":\"INR\",\"signature\":\"e68b61e77a9fe3c8112fd94a60710d8a8db1be7be9dde19a053ed2059b504773867666412a317e4a7d2970eb030fe5bae1b563185ff4bbe7e5d70749fe579265\",\"txnInitDate\":\"2021-05-19 10:02:13\",\"txnCompleteDate\":\"2021-05-19 10:02:20\"},\"payModeSpecificData\":{\"subChannel\":[\"NB\"],\"bankDetails\":{\"otsBankId\":4001,\"bankTxnId\":\"mjkIiG02WIDcXNzixeKA\",\"otsBankName\":\"OTS Bank\"}},\"extras\":{},\"custDetails\":{\"billingInfo\":{}},\"responseDetails\":{\"statusCode\":\"OTS0000\",\"message\":\"SUCCESS\",\"description\":\"TRANSACTION IS SUCCESSFUL.\"}}}";

	    ObjectMapper mapper = new ObjectMapper();
	    try
	    {
	      ResponseParser authRequestTO = (ResponseParser)mapper.readValue(resp, ResponseParser.class);
	      System.out.println(authRequestTO);
	      System.out.println();
	      System.out.println("Transaction Result------: " + authRequestTO.getPayInstrument().getResponseDetails().getMessage());
	      System.out.println("Merchant Txn ID---------: " + authRequestTO.getPayInstrument().getMerchDetails().getMerchTxnId());
	      System.out.println("Merchant Txn Date-------: " + authRequestTO.getPayInstrument().getMerchDetails().getMerchTxnDate());
	      System.out.println("Bank Txn ID-------------: " + authRequestTO.getPayInstrument().getPayModeSpecificData().getBankDetails().getBankTxnId());
	    }
	    catch (IOException e)
	    {
	      e.printStackTrace();
	    }
	  }
}
