package com.nttdatapay.aipayclient.model;
/**
 * @author SurajChavan
 *
 */
public class BillingInfo {
	

}
