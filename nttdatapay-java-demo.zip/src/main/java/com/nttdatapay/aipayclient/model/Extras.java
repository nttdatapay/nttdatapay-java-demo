package com.nttdatapay.aipayclient.model;
/**
 * @author SurajChavan
 *
 */
public class Extras {
	
		private String udf1;
		private String udf2;
		private String udf3;
		private String udf4;
		private String udf5;
		public String getUdf1() {
			return udf1;
		}
		public void setUdf1(String udf1) {
			this.udf1 = udf1;
		}
		public String getUdf2() {
			return udf2;
		}
		public void setUdf2(String udf2) {
			this.udf2 = udf2;
		}
		public String getUdf3() {
			return udf3;
		}
		public void setUdf3(String udf3) {
			this.udf3 = udf3;
		}
		public String getUdf4() {
			return udf4;
		}
		public void setUdf4(String udf4) {
			this.udf4 = udf4;
		}
		public String getUdf5() {
			return udf5;
		}
		public void setUdf5(String udf5) {
			this.udf5 = udf5;
		}
		@Override
		public String toString() {
			return "Extras [udf1=" + udf1 + ", udf2=" + udf2 + ", udf3=" + udf3 + ", udf4=" + udf4 + ", udf5=" + udf5
					+ ", getUdf1()=" + getUdf1() + ", getUdf2()=" + getUdf2() + ", getUdf3()=" + getUdf3()
					+ ", getUdf4()=" + getUdf4() + ", getUdf5()=" + getUdf5() + ", getClass()=" + getClass()
					+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
		}
	
	

}
