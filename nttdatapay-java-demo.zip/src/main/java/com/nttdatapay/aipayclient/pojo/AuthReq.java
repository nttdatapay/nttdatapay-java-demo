package com.nttdatapay.aipayclient.pojo;

public class AuthReq {
String merchId;
String encData;
public String getMerchId() {
	return merchId;
}
public void setMerchId(String merchId) {
	this.merchId = merchId;
}
public String getEncData() {
	return encData;
}
public void setEncData(String encData) {
	this.encData = encData;
}
}
