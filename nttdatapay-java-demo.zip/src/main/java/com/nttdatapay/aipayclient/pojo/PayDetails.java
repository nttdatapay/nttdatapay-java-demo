package com.nttdatapay.aipayclient.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author SurajChavan
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PayDetails {

	private String amount;
	private List<ProdDetail> prodDetails;
	private String product;
	private String custAccNo;
	private String txnCurrency;
	

	
}
