package com.nttdatapay.aipayclient.pojo;

/**
 * @author SurajChavan
 *
 */
public class ResponseUrls {

}
