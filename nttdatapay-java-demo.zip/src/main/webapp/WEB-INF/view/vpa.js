
// Process For virtual address validation
function vpavalidate(vpaId,txnType)
{
         $('#gperr').html("");

         $('#userNameVal').val("OTS Tester");
         
         $("#paymentProcess").removeAttr('disabled');

}

function vpavalidate(vpaId,txnType,merchId)
{	
	
	var vpa = "";
	
	if(vpaId=="virtualAddGPEXT")
		vpa = document.getElementById("virtualAddGP").value;
	else
		vpa = document.getElementById(vpaId).value;
	
	$('#upierr').html("");	
	
	var vpaResp = '';
	
	if(vpa !="") {
		
		if(vpaId=="virtualAddGPEXT") {

			if(vpa.indexOf("@")>=1) {
				$('#gperr').html("<font color='red'>Please enter valid VPA.</font>");
				$('#virtualAddGP').val("");
				$('#userNameValGP').val("");
				$('#virtualAddGP').focus();
				return false;
			}else{				
				vpa = vpa+document.getElementById(vpaId).value;
			}
		}
	
		if(vpa.indexOf("@")<=0)
		{
			if(vpaId=="virtualAdd"){
				$('#upierr').html("<font color='red'>Please enter valid VPA.</font>");
				$('#virtualAdd').val("");
				$('#userNameVal').val("");
				$('#virtualAdd').focus();
			}else if(vpaId=="virtualAddGPEXT"){
				$('#gperr').html("<font color='red'>Please enter valid VPA.</font>");
				$('#virtualAddGP').val("");
				$('#userNameValGP').val("");
				$('#virtualAddGP').focus();
			
			}	
		}else {
			
			var info11 = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);
			var info22 = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);
			
			var aesUtil1 = new AesUtil(keySize, iterationCount);
			
			var otsHashToken = $("#otsHashToken").val();
			var otsRouter = $("#otsRouter").val();
			var otsInfo = $("#otsInfo").val();
			var tracerId = $("#tracerId").val();
			
			data1 = JSON.stringify({
				
				 "virtualAdd" : vpa,
				 "txnType" : txnType,
				 "tdata" : $.now(),
				 "merchId" : merchId,
				 "action" : "vpaVal",
				 "tracerId" : tracerId,
				
				"otsHashToken" : otsHashToken,
				"otsRouter" : otsRouter,
				"otsInfo" : otsInfo
				});
			
			var ciphertext1 = aesUtil1.encrypt(info11, info22, passPhrase, data1);
			debugger;
		
			$.ajax({
			
			/*url : "https://caller.atomtech.in/ots/page/val",*/
				url : "http://172.21.21.116:8380/ots/binval",
			type : "POST",
			contentType : 'application/json',
			
			data : JSON.stringify({
				td : ciphertext1,
				i1 : info11,
				i2 : info22,
				a : "vpaVal"
			}),
			
			success : function(responseText){
				
			debugger;
			
			if(responseText.serviceResponseCode =='BVS0000')
			{
				if(vpaId=="virtualAdd"){
					$('#upierr').html("");						
					$('#userNameVal').val(responseText.custName);						
				}else if(vpaId=="virtualAddGPEXT"){
					$('#gperr').html("");				
				
					$('#userNameValGP').val(responseText.custName);
				}
				$("#paymentProcess").removeAttr('disabled');
			}			
			else
			{
				if(vpaId=="virtualAdd"){
					$('#upierr').html("<font color='red'>"+responseText.serviceDescription+"</font>");
					$('#virtualAdd').val("");
					$('#userNameVal').val("");
					$('#virtualAdd').focus();
				}else if(vpaId=="virtualAddGPEXT"){
					$('#gperr').html("<font color='red'>"+responseText.serviceDescription+"</font>");
					$('#virtualAddGP').val("");
					$('#userNameValGP').val("");
					$('#virtualAddGP').focus();
				}				
			}	
			},
			error : function(jqXhr, textStatus, errorThrown) {
				
					if(vpaId=="virtualAdd"){
							$('#upierr').html("<font color='red'> Please enter a valid VPA.</font>");
							$('#virtualAdd').val("");
							$('#userNameVal').val("");
							$('#virtualAdd').focus();
					}else if(vpaId=="virtualAddGPEXT"){
							$('#gperr').html("<font color='red'> Please enter a valid VPA.</font>");
							$('#virtualAddGP').val("");
							$('#userNameValGP').val("");
							$('#virtualAddGP').focus();
					}
			}
			});
		}
	}
	else{
			
		if(vpaId=="virtualAdd"){
			$('#virtualAdd').val("");
			$('#userNameVal').val("");
			$('#virtualAdd').focus();
		}else if(vpaId=="virtualAddGPEXT"){
			$('#virtualAddGP').val("");
			$('#userNameValGP').val("");
			$('#virtualAddGP').focus();
		}		
	

}
}
