package com.nttdatapay.aipayclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AipayclinetApplicationTests {

	@Test
	void contextLoads() {
	}

}
